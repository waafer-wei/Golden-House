# 🚀 快速部署到 Vercel

## 一键部署脚本（推荐）

```bash
# 在项目根目录执行
bash scripts/deploy-vercel.sh
```

脚本会自动完成：
1. ✅ 初始化 Git 仓库
2. ✅ 提交代码
3. ✅ 配置 GitHub 远程仓库
4. ✅ 推送代码到 GitHub

## 手动部署步骤

### 1. 推送代码到 GitHub

```bash
# 初始化 Git
git init
git add .
git commit -m "feat: 初始化黄金屋小说网项目"

# 添加远程仓库（替换为你的仓库地址）
git remote add origin https://github.com/你的用户名/仓库名.git

# 推送代码
git branch -M main
git push -u origin main
```

### 2. 在 Vercel 导入项目

1. 访问 https://vercel.com 并登录
2. 点击 "Add New..." → "Project"
3. 选择你的 GitHub 仓库
4. 点击 "Import"
5. 点击 "Deploy" 开始部署

### 3. 绑定你的域名

部署完成后：

1. 进入项目 "Settings" → "Domains"
2. 添加你的域名（如 `huangjinwu.com`）
3. 在域名管理后台添加 DNS 记录：

| 类型 | 名称 | 值 |
|------|------|-----|
| CNAME | @ | cname.vercel-dns.com |
| CNAME | www | cname.vercel-dns.com |

4. 等待 DNS 生效（10分钟 - 24小时）

## 详细文档

完整部署指南请查看：[VERCEL_DEPLOY.md](./VERCEL_DEPLOY.md)

## 常见问题

### Q: 部署失败怎么办？
A: 本地运行 `pnpm build` 检查是否有错误

### Q: DNS 配置后访问 404？
A: 等待 DNS 生效，通常需要 10-30 分钟

### Q: 如何查看部署日志？
A: 访问 Vercel Dashboard → 你的项目 → Deployments

## 联系支持

- Vercel 文档：https://vercel.com/docs
- Next.js 部署：https://nextjs.org/docs/deployment
