#!/bin/bash

# 🚀 黄金屋小说网 - Vercel 一键部署脚本
# 使用方法: bash scripts/deploy-vercel.sh

set -e

echo "🎯 黄金屋小说网 - Vercel 部署脚本"
echo "===================================="
echo ""

# 颜色定义
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# 检查 Git 是否已安装
if ! command -v git &> /dev/null; then
    echo -e "${RED}❌ Git 未安装，请先安装 Git${NC}"
    exit 1
fi

# 检查是否已在 Git 仓库中
if [ -d ".git" ]; then
    echo -e "${YELLOW}⚠️  检测到已存在 Git 仓库${NC}"
    read -p "是否重新初始化？(y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        rm -rf .git
    else
        echo "跳过 Git 初始化"
    fi
fi

# 初始化 Git 仓库
if [ ! -d ".git" ]; then
    echo -e "${GREEN}✓ 初始化 Git 仓库...${NC}"
    git init
fi

# 添加所有文件
echo -e "${GREEN}✓ 添加文件到暂存区...${NC}"
git add .

# 提交代码
echo -e "${GREEN}✓ 提交代码...${NC}"
git commit -m "feat: 初始化黄金屋小说网项目"

# 询问 GitHub 仓库地址
echo ""
echo "📦 请提供你的 GitHub 仓库信息"
echo "------------------------------"

read -p "请输入 GitHub 用户名: " GITHUB_USERNAME
read -p "请输入仓库名称 (默认: huangjinwu-novel): " REPO_NAME

REPO_NAME=${REPO_NAME:-huangjinwu-novel}

REMOTE_URL="https://github.com/${GITHUB_USERNAME}/${REPO_NAME}.git"

echo ""
echo -e "${YELLOW}📌 仓库地址: ${REMOTE_URL}${NC}"
echo ""

# 添加远程仓库
echo -e "${GREEN}✓ 添加远程仓库...${NC}"
if git remote get-url origin &> /dev/null; then
    git remote set-url origin "$REMOTE_URL"
else
    git remote add origin "$REMOTE_URL"
fi

# 重命名主分支
echo -e "${GREEN}✓ 设置主分支为 main...${NC}"
git branch -M main

# 推送到 GitHub
echo ""
echo -e "${YELLOW}🚀 准备推送到 GitHub...${NC}"
echo ""
echo "请确保："
echo "1. 已在 GitHub 上创建仓库: ${REMOTE_URL}"
echo "2. 仓库为空或允许推送"
echo ""
read -p "是否继续推送？(y/n) " -n 1 -r
echo

if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${GREEN}✓ 推送代码到 GitHub...${NC}"
    git push -u origin main

    if [ $? -eq 0 ]; then
        echo ""
        echo -e "${GREEN}✅ 代码推送成功！${NC}"
        echo ""
        echo "📋 下一步操作："
        echo "1. 访问 GitHub 仓库: ${REMOTE_URL}"
        echo "2. 访问 Vercel: https://vercel.com"
        echo "3. 登录后点击 'Add New' → 'Project'"
        echo "4. 导入你的 GitHub 仓库"
        echo "5. 点击 'Deploy' 开始部署"
        echo ""
        echo "📖 详细部署指南请查看: VERCEL_DEPLOY.md"
    else
        echo ""
        echo -e "${RED}❌ 推送失败，请检查：${NC}"
        echo "1. GitHub 仓库是否已创建"
        echo "2. 是否有仓库的写权限"
        echo "3. 网络连接是否正常"
        echo ""
        echo "手动推送命令："
        echo "git push -u origin main"
    fi
else
    echo ""
    echo -e "${YELLOW}跳过推送步骤${NC}"
    echo ""
    echo "手动推送命令："
    echo "git push -u origin main"
fi

echo ""
echo "✅ 脚本执行完成！"
