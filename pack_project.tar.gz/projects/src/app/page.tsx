'use client';

import Link from 'next/link';
import { mockNovels, mockCategories } from '@/data/mock-novels';
import type { Novel } from '@/types/novel';
import { Search, Clock, BookOpen, Star } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

export default function Home() {
  const featuredNovels = mockNovels.slice(0, 6);
  const latestNovels = mockNovels.slice(0, 12);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* 顶部导航栏 - 笔趣阁风格黄色背景 */}
      <header className="bg-yellow-500 border-b-2 border-yellow-600 shadow-md">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between flex-wrap gap-4">
            {/* 网站Logo */}
            <Link href="/" className="flex items-center space-x-2 group">
              <BookOpen className="h-8 w-8 text-white group-hover:scale-110 transition-transform" />
              <h1 className="text-2xl font-bold text-white tracking-wider">
                黄金屋小说网
              </h1>
            </Link>

            {/* 搜索框 */}
            <div className="flex-1 max-w-md mx-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
                <Input
                  type="text"
                  placeholder="搜索小说、作者..."
                  className="pl-10 pr-4 py-2 bg-white border-none focus:ring-2 focus:ring-yellow-300"
                />
              </div>
            </div>

            {/* 导航链接 */}
            <nav className="flex items-center space-x-4 text-white text-sm">
              <Link href="/" className="hover:text-yellow-200 transition-colors font-medium">
                首页
              </Link>
              <Link href="/categories" className="hover:text-yellow-200 transition-colors">
                全本
              </Link>
              <Link href="/rank" className="hover:text-yellow-200 transition-colors">
                排行榜
              </Link>
              <Link href="/categories" className="hover:text-yellow-200 transition-colors">
                分类
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* 分类导航 */}
      <div className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 py-2">
          <div className="flex items-center space-x-4 text-sm flex-wrap gap-y-2">
            <span className="font-semibold text-gray-700">分类：</span>
            {mockCategories.map((category) => (
              <Link
                key={category.id}
                href={`/categories/${category.id}`}
                className="text-gray-600 hover:text-yellow-600 transition-colors flex items-center space-x-1"
              >
                <span>{category.name}</span>
                <span className="text-gray-400 text-xs">({category.count})</span>
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* 主要内容 */}
      <main className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* 左侧主内容区 */}
          <div className="lg:col-span-3 space-y-6">
            {/* 推荐小说区域 */}
            <section>
              <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                <div className="bg-gradient-to-r from-yellow-500 to-yellow-600 px-4 py-3 rounded-t-lg">
                  <h2 className="text-lg font-bold text-white flex items-center">
                    <Star className="h-5 w-5 mr-2" />
                    精品推荐
                  </h2>
                </div>
                <div className="p-4">
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {featuredNovels.map((novel) => (
                      <NovelCard key={novel.id} novel={novel} />
                    ))}
                  </div>
                </div>
              </div>
            </section>

            {/* 最新更新列表 */}
            <section>
              <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                <div className="bg-gradient-to-r from-blue-500 to-blue-600 px-4 py-3 rounded-t-lg">
                  <h2 className="text-lg font-bold text-white flex items-center">
                    <Clock className="h-5 w-5 mr-2" />
                    最新更新
                  </h2>
                </div>
                <div className="divide-y divide-gray-100">
                  {latestNovels.map((novel) => (
                    <NovelListItem key={novel.id} novel={novel} />
                  ))}
                </div>
                <div className="p-4 text-center">
                  <Button variant="outline" className="w-full hover:bg-yellow-50 hover:border-yellow-300">
                    查看更多更新
                  </Button>
                </div>
              </div>
            </section>
          </div>

          {/* 右侧边栏 */}
          <div className="space-y-6">
            {/* 热门排行 */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="bg-gradient-to-r from-red-500 to-red-600 px-4 py-3 rounded-t-lg">
                <h3 className="font-bold text-white">热门排行</h3>
              </div>
              <div className="p-4 space-y-3">
                {mockNovels.slice(0, 10).map((novel, index) => (
                  <Link
                    key={novel.id}
                    href={`/novel/${novel.id}`}
                    className="flex items-start space-x-3 group hover:bg-gray-50 p-2 rounded transition-colors"
                  >
                    <span
                      className={`flex-shrink-0 w-6 h-6 flex items-center justify-center text-sm font-bold rounded-full ${
                        index < 3
                          ? 'bg-red-500 text-white'
                          : 'bg-gray-200 text-gray-600'
                      }`}
                    >
                      {index + 1}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-800 group-hover:text-yellow-600 transition-colors truncate">
                        {novel.title}
                      </p>
                      <p className="text-xs text-gray-500">{novel.author}</p>
                    </div>
                  </Link>
                ))}
              </div>
            </div>

            {/* 最新入库 */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="bg-gradient-to-r from-green-500 to-green-600 px-4 py-3 rounded-t-lg">
                <h3 className="font-bold text-white">最新入库</h3>
              </div>
              <div className="p-4 space-y-3">
                {mockNovels.slice(0, 8).map((novel) => (
                  <Link
                    key={novel.id}
                    href={`/novel/${novel.id}`}
                    className="flex items-start space-x-3 group hover:bg-gray-50 p-2 rounded transition-colors"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-800 group-hover:text-yellow-600 transition-colors truncate">
                        {novel.title}
                      </p>
                      <p className="text-xs text-gray-500">{novel.author}</p>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* 底部 */}
      <footer className="bg-gray-800 text-gray-400 py-8 mt-12">
        <div className="container mx-auto px-4">
          <div className="text-center space-y-4">
            <p className="text-sm">
              黄金屋小说网 - 免费小说阅读网站 | 每天更新最新最热的小说
            </p>
            <p className="text-xs">
              本站所有小说为转载作品，所有章节均由网友上传，转载至本站只是为了宣传本书让更多读者欣赏。
            </p>
            <p className="text-xs">
              如发现本站有侵犯权利的内容，请联系站长删除，联系邮箱：admin@huangjinwu.com
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

// 小说卡片组件
function NovelCard({ novel }: { novel: Novel }) {
  return (
    <Link href={`/novel/${novel.id}`} className="group block">
      <div className="bg-gray-50 rounded-lg overflow-hidden hover:shadow-lg transition-shadow border border-gray-100 group-hover:border-yellow-300">
        <div className="aspect-[3/4] bg-gradient-to-br from-yellow-100 to-yellow-200 relative overflow-hidden">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center p-4">
              <BookOpen className="h-12 w-12 mx-auto text-yellow-600 mb-2" />
              <p className="text-xs text-yellow-700 font-medium">{novel.title}</p>
            </div>
          </div>
          <div className="absolute top-2 right-2 bg-yellow-500 text-white text-xs px-2 py-1 rounded">
            {novel.status}
          </div>
        </div>
        <div className="p-3">
          <h3 className="font-bold text-gray-800 text-sm mb-1 group-hover:text-yellow-600 transition-colors truncate">
            {novel.title}
          </h3>
          <p className="text-xs text-gray-600 mb-1">{novel.author}</p>
          <p className="text-xs text-gray-500 truncate">{novel.description}</p>
        </div>
      </div>
    </Link>
  );
}

// 小说列表项组件
function NovelListItem({ novel }: { novel: Novel }) {
  return (
    <Link
      href={`/novel/${novel.id}`}
      className="block p-4 hover:bg-yellow-50 transition-colors"
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-1">
            <h3 className="font-bold text-gray-800 text-sm hover:text-yellow-600 transition-colors">
              {novel.title}
            </h3>
            <span className="text-xs text-gray-500">/</span>
            <span className="text-xs text-gray-600">{novel.author}</span>
          </div>
          <div className="flex items-center space-x-4 text-xs text-gray-500">
            <span className="flex items-center">
              <BookOpen className="h-3 w-3 mr-1" />
              {novel.category}
            </span>
            <span className="flex items-center">
              <Clock className="h-3 w-3 mr-1" />
              {novel.lastUpdateTime}
            </span>
          </div>
        </div>
        <div className="text-right">
          <p className="text-xs text-gray-500">最新章节</p>
          <p className="text-xs text-gray-600 hover:text-yellow-600 truncate max-w-[150px]">
            {novel.chapters[novel.chapters.length - 1]?.title || '暂无章节'}
          </p>
        </div>
      </div>
    </Link>
  );
}
