'use client';

import { useState } from 'react';
import Link from 'next/link';
import { mockNovels, mockCategories } from '@/data/mock-novels';
import type { Novel } from '@/types/novel';
import {
  BookOpen,
  Trophy,
  Flame,
  Clock,
  Star,
  User,
  Calendar,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function RankPage() {
  const [activeTab, setActiveTab] = useState('click');

  // 模拟不同排序
  const clickRank = [...mockNovels].sort((a, b) => Math.random() - 0.5);
  const newRank = [...mockNovels].sort((a, b) =>
    b.lastUpdateTime.localeCompare(a.lastUpdateTime)
  );
  const hotRank = [...mockNovels].sort((a, b) => b.chapters.length - a.chapters.length);
  const completeRank = mockNovels.filter((n) => n.status === '已完结');
  const recommendRank = [...mockNovels].sort((a, b) => Math.random() - 0.5);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* 顶部导航 */}
      <header className="bg-yellow-500 border-b-2 border-yellow-600 shadow-md">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <BookOpen className="h-7 w-7 text-white" />
              <h1 className="text-xl font-bold text-white">黄金屋小说网</h1>
            </Link>
            <nav className="flex items-center space-x-4 text-white text-sm">
              <Link href="/" className="hover:text-yellow-200 transition-colors">
                首页
              </Link>
              <Link href="/categories" className="hover:text-yellow-200 transition-colors">
                分类
              </Link>
              <Link href="/rank" className="hover:text-yellow-200 transition-colors font-medium">
                排行
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* 页面标题 */}
      <div className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center space-x-3">
            <Trophy className="h-8 w-8 text-yellow-500" />
            <h2 className="text-2xl font-bold text-gray-800">排行榜</h2>
          </div>
        </div>
      </div>

      {/* 主要内容 */}
      <main className="container mx-auto px-4 py-6">
        <div className="max-w-4xl mx-auto">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-5 bg-white border border-gray-200">
              <TabsTrigger value="click" className="data-[state=active]:bg-yellow-500 data-[state=active]:text-white">
                <Flame className="h-4 w-4 mr-2" />
                点击榜
              </TabsTrigger>
              <TabsTrigger value="new" className="data-[state=active]:bg-yellow-500 data-[state=active]:text-white">
                <Clock className="h-4 w-4 mr-2" />
                新书榜
              </TabsTrigger>
              <TabsTrigger value="hot" className="data-[state=active]:bg-yellow-500 data-[state=active]:text-white">
                <Star className="h-4 w-4 mr-2" />
                热门榜
              </TabsTrigger>
              <TabsTrigger value="complete" className="data-[state=active]:bg-yellow-500 data-[state=active]:text-white">
                <BookOpen className="h-4 w-4 mr-2" />
                完结榜
              </TabsTrigger>
              <TabsTrigger value="recommend" className="data-[state=active]:bg-yellow-500 data-[state=active]:text-white">
                <Star className="h-4 w-4 mr-2" />
                推荐榜
              </TabsTrigger>
            </TabsList>

            {/* 点击榜 */}
            <TabsContent value="click" className="space-y-3">
              <RankList novels={clickRank} title="点击排行榜" />
            </TabsContent>

            {/* 新书榜 */}
            <TabsContent value="new" className="space-y-3">
              <RankList novels={newRank} title="新书排行榜" />
            </TabsContent>

            {/* 热门榜 */}
            <TabsContent value="hot" className="space-y-3">
              <RankList novels={hotRank} title="热门排行榜" />
            </TabsContent>

            {/* 完结榜 */}
            <TabsContent value="complete" className="space-y-3">
              <RankList novels={completeRank} title="完结排行榜" />
            </TabsContent>

            {/* 推荐榜 */}
            <TabsContent value="recommend" className="space-y-3">
              <RankList novels={recommendRank} title="推荐排行榜" />
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* 底部 */}
      <footer className="bg-gray-800 text-gray-400 py-8 mt-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm">黄金屋小说网 - 免费小说阅读网站</p>
        </div>
      </footer>
    </div>
  );
}

// 排行榜列表组件
function RankList({ novels, title }: { novels: Novel[]; title: string }) {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="bg-gradient-to-r from-yellow-500 to-yellow-600 px-4 py-3 rounded-t-lg">
        <h3 className="font-bold text-white">{title}</h3>
      </div>
      <div className="divide-y divide-gray-100">
        {novels.map((novel, index) => (
          <RankItem key={novel.id} novel={novel} rank={index + 1} />
        ))}
      </div>
    </div>
  );
}

// 排行榜单项组件
function RankItem({ novel, rank }: { novel: Novel; rank: number }) {
  const getRankColor = (rank: number) => {
    if (rank === 1) return 'bg-gradient-to-r from-red-500 to-red-600';
    if (rank === 2) return 'bg-gradient-to-r from-orange-500 to-orange-600';
    if (rank === 3) return 'bg-gradient-to-r from-yellow-500 to-yellow-600';
    return 'bg-gray-200 text-gray-600';
  };

  const getRankTextColor = (rank: number) => {
    if (rank <= 3) return 'text-white';
    return 'text-gray-700';
  };

  return (
    <Link
      href={`/novel/${novel.id}`}
      className="block p-4 hover:bg-yellow-50 transition-colors group"
    >
      <div className="flex items-start space-x-4">
        {/* 排名 */}
        <div
          className={`flex-shrink-0 w-12 h-12 flex items-center justify-center rounded-lg font-bold text-xl ${getRankColor(
            rank
          )} ${getRankTextColor(rank)}`}
        >
          {rank}
        </div>

        {/* 封面 */}
        <div className="flex-shrink-0">
          <div className="w-16 h-20 bg-gradient-to-br from-yellow-100 to-yellow-200 rounded flex items-center justify-center">
            <BookOpen className="h-6 w-6 text-yellow-600" />
          </div>
        </div>

        {/* 信息 */}
        <div className="flex-1 min-w-0">
          <h3 className="font-bold text-gray-800 mb-1 group-hover:text-yellow-600 transition-colors flex items-center">
            {novel.title}
            {rank <= 3 && (
              <span className="ml-2 text-xs">
                {rank === 1 && '🥇'}
                {rank === 2 && '🥈'}
                {rank === 3 && '🥉'}
              </span>
            )}
          </h3>
          <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
            <span className="flex items-center">
              <User className="h-3 w-3 mr-1" />
              {novel.author}
            </span>
            <span className="flex items-center">
              <BookOpen className="h-3 w-3 mr-1" />
              {novel.category}
            </span>
            <span className="px-2 py-0.5 bg-yellow-100 text-yellow-700 rounded text-xs">
              {novel.status}
            </span>
          </div>
          <p className="text-sm text-gray-600 line-clamp-2">{novel.description}</p>
        </div>

        {/* 更新信息 */}
        <div className="text-right text-xs text-gray-500">
          <div className="flex items-center justify-end mb-1">
            <Calendar className="h-3 w-3 mr-1" />
            {novel.lastUpdateTime}
          </div>
          <div className="flex items-center justify-end">
            <BookOpen className="h-3 w-3 mr-1" />
            {novel.chapters.length} 章
          </div>
        </div>
      </div>
    </Link>
  );
}
