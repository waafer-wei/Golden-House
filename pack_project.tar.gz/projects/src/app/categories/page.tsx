'use client';

import Link from 'next/link';
import { mockNovels, mockCategories } from '@/data/mock-novels';
import type { Novel } from '@/types/novel';
import {
  BookOpen,
  User,
  Clock,
  Grid,
  List as ListIcon,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState } from 'react';

export default function CategoriesPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const filteredNovels = selectedCategory
    ? mockNovels.filter((novel) => novel.category === selectedCategory)
    : mockNovels;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* 顶部导航 */}
      <header className="bg-yellow-500 border-b-2 border-yellow-600 shadow-md">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <BookOpen className="h-7 w-7 text-white" />
              <h1 className="text-xl font-bold text-white">黄金屋小说网</h1>
            </Link>
            <nav className="flex items-center space-x-4 text-white text-sm">
              <Link href="/" className="hover:text-yellow-200 transition-colors">
                首页
              </Link>
              <Link href="/categories" className="hover:text-yellow-200 transition-colors font-medium">
                分类
              </Link>
              <Link href="/rank" className="hover:text-yellow-200 transition-colors">
                排行
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* 分类导航 */}
      <div className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-800">小说分类</h2>
            <div className="flex items-center space-x-2">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className={viewMode === 'grid' ? 'bg-yellow-500 hover:bg-yellow-600' : ''}
              >
                <Grid className="h-4 w-4 mr-2" />
                网格
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('list')}
                className={viewMode === 'list' ? 'bg-yellow-500 hover:bg-yellow-600' : ''}
              >
                <ListIcon className="h-4 w-4 mr-2" />
                列表
              </Button>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <Button
              variant={!selectedCategory ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory('')}
              className={!selectedCategory ? 'bg-yellow-500 hover:bg-yellow-600' : ''}
            >
              全部 ({mockNovels.length})
            </Button>
            {mockCategories.map((cat) => (
              <Button
                key={cat.id}
                variant={selectedCategory === cat.name ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(cat.name)}
                className={
                  selectedCategory === cat.name ? 'bg-yellow-500 hover:bg-yellow-600' : ''
                }
              >
                {cat.name} ({cat.count})
              </Button>
            ))}
          </div>
        </div>
      </div>

      {/* 小说列表 */}
      <main className="container mx-auto px-4 py-6">
        <div className="max-w-6xl mx-auto">
          {selectedCategory && (
            <div className="mb-4 text-sm text-gray-600">
              <span>当前分类：</span>
              <span className="font-bold text-yellow-600">{selectedCategory}</span>
              <span className="ml-2">共 {filteredNovels.length} 本小说</span>
            </div>
          )}

          {viewMode === 'grid' ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
              {filteredNovels.map((novel) => (
                <NovelCard key={novel.id} novel={novel} />
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 divide-y divide-gray-100">
              {filteredNovels.map((novel) => (
                <NovelListItem key={novel.id} novel={novel} />
              ))}
            </div>
          )}
        </div>
      </main>

      {/* 底部 */}
      <footer className="bg-gray-800 text-gray-400 py-8 mt-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm">黄金屋小说网 - 免费小说阅读网站</p>
        </div>
      </footer>
    </div>
  );
}

// 小说卡片组件
function NovelCard({ novel }: { novel: Novel }) {
  return (
    <Link href={`/novel/${novel.id}`} className="group block">
      <div className="bg-white rounded-lg overflow-hidden hover:shadow-lg transition-all border border-gray-200 group-hover:border-yellow-300">
        <div className="aspect-[3/4] bg-gradient-to-br from-yellow-100 to-yellow-200 relative overflow-hidden">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center p-4">
              <BookOpen className="h-12 w-12 mx-auto text-yellow-600 mb-2" />
              <p className="text-xs text-yellow-700 font-medium">{novel.title}</p>
            </div>
          </div>
          <div className="absolute top-2 right-2 bg-yellow-500 text-white text-xs px-2 py-1 rounded">
            {novel.status}
          </div>
        </div>
        <div className="p-3">
          <h3 className="font-bold text-gray-800 text-sm mb-1 group-hover:text-yellow-600 transition-colors truncate">
            {novel.title}
          </h3>
          <p className="text-xs text-gray-600 mb-1">{novel.author}</p>
          <p className="text-xs text-gray-500 truncate">{novel.category}</p>
        </div>
      </div>
    </Link>
  );
}

// 小说列表项组件
function NovelListItem({ novel }: { novel: Novel }) {
  return (
    <Link
      href={`/novel/${novel.id}`}
      className="block p-4 hover:bg-yellow-50 transition-colors"
    >
      <div className="flex items-start justify-between">
        <div className="flex items-start space-x-4 flex-1">
          <div className="w-20 h-28 bg-gradient-to-br from-yellow-100 to-yellow-200 rounded flex-shrink-0 flex items-center justify-center">
            <BookOpen className="h-6 w-6 text-yellow-600" />
          </div>
          <div className="flex-1">
            <h3 className="font-bold text-gray-800 mb-1 hover:text-yellow-600 transition-colors">
              {novel.title}
            </h3>
            <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
              <span className="flex items-center">
                <User className="h-3 w-3 mr-1" />
                {novel.author}
              </span>
              <span className="flex items-center">
                <BookOpen className="h-3 w-3 mr-1" />
                {novel.category}
              </span>
              <span className="px-2 py-0.5 bg-yellow-100 text-yellow-700 rounded text-xs">
                {novel.status}
              </span>
            </div>
            <p className="text-sm text-gray-600 line-clamp-2">{novel.description}</p>
          </div>
        </div>
        <div className="text-right text-xs text-gray-500">
          <p className="mb-1">更新时间</p>
          <p>{novel.lastUpdateTime}</p>
        </div>
      </div>
    </Link>
  );
}
