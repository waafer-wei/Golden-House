'use client';

import { useParams } from 'next/navigation';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { getNovelById, mockNovels } from '@/data/mock-novels';
import type { Novel, Chapter } from '@/types/novel';
import {
  BookOpen,
  User,
  Clock,
  ArrowLeft,
  ArrowRight,
  List,
  Home,
  Share2,
  Star,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export default function NovelDetailPage() {
  const params = useParams();
  const [novel, setNovel] = useState<Novel | null>(null);
  const [selectedChapter, setSelectedChapter] = useState<Chapter | null>(null);

  useEffect(() => {
    const novelId = params.id as string;
    const foundNovel = getNovelById(novelId);
    setNovel(foundNovel || null);
  }, [params.id]);

  if (!novel) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-yellow-500 border-b-2 border-yellow-600">
          <div className="container mx-auto px-4 py-3">
            <Link href="/" className="text-white font-bold text-xl">
              黄金屋小说网
            </Link>
          </div>
        </header>
        <div className="container mx-auto px-4 py-12">
          <div className="text-center">
            <p className="text-gray-600">未找到该小说</p>
            <Link href="/">
              <Button className="mt-4">返回首页</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const currentChapterIndex = selectedChapter
    ? novel.chapters.findIndex((ch) => ch.id === selectedChapter.id)
    : -1;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* 顶部导航 */}
      <header className="bg-yellow-500 border-b-2 border-yellow-600 shadow-md">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <BookOpen className="h-7 w-7 text-white" />
              <h1 className="text-xl font-bold text-white">黄金屋小说网</h1>
            </Link>
            <nav className="flex items-center space-x-4 text-white text-sm">
              <Link href="/" className="hover:text-yellow-200 transition-colors">
                <Home className="h-4 w-4 inline mr-1" />
                首页
              </Link>
              <Link href="/categories" className="hover:text-yellow-200 transition-colors">
                分类
              </Link>
              <Link href="/rank" className="hover:text-yellow-200 transition-colors">
                排行
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* 面包屑导航 */}
      <div className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 py-2">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Link href="/" className="hover:text-yellow-600">
              首页
            </Link>
            <span>/</span>
            <Link href={`/categories/${novel.category}`} className="hover:text-yellow-600">
              {novel.category}
            </Link>
            <span>/</span>
            <span className="text-gray-800 font-medium">{novel.title}</span>
          </div>
        </div>
      </div>

      {/* 主要内容 */}
      <main className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* 左侧书籍信息 */}
          <div className="lg:col-span-2 space-y-6">
            {/* 书籍信息卡片 */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="p-6">
                <div className="flex flex-col md:flex-row gap-6">
                  {/* 封面 */}
                  <div className="flex-shrink-0">
                    <div className="w-48 h-64 bg-gradient-to-br from-yellow-100 to-yellow-200 rounded-lg flex items-center justify-center shadow-md">
                      <div className="text-center">
                        <BookOpen className="h-16 w-16 mx-auto text-yellow-600 mb-2" />
                        <p className="text-sm text-yellow-700 font-medium">{novel.title}</p>
                      </div>
                    </div>
                  </div>

                  {/* 书籍信息 */}
                  <div className="flex-1">
                    <h1 className="text-2xl font-bold text-gray-800 mb-3">
                      {novel.title}
                    </h1>

                    <div className="space-y-2 mb-4">
                      <div className="flex items-center text-sm text-gray-600">
                        <User className="h-4 w-4 mr-2 text-gray-400" />
                        <span className="mr-4">作者：{novel.author}</span>
                        <span className="mr-4">分类：{novel.category}</span>
                        <span>状态：{novel.status}</span>
                      </div>
                      <div className="flex items-center text-sm text-gray-600">
                        <Clock className="h-4 w-4 mr-2 text-gray-400" />
                        <span>更新时间：{novel.lastUpdateTime}</span>
                      </div>
                      <div className="flex items-center text-sm text-gray-600">
                        <List className="h-4 w-4 mr-2 text-gray-400" />
                        <span>章节总数：{novel.chapters.length}</span>
                      </div>
                    </div>

                    <div className="mb-4">
                      <h3 className="font-semibold text-gray-800 mb-2">简介：</h3>
                      <p className="text-sm text-gray-600 leading-relaxed">{novel.description}</p>
                    </div>

                    <div className="flex gap-3">
                      <Button
                        onClick={() => setSelectedChapter(novel.chapters[0])}
                        className="flex-1 bg-yellow-500 hover:bg-yellow-600 text-white"
                      >
                        开始阅读
                      </Button>
                      <Button variant="outline" className="flex-1">
                        <Star className="h-4 w-4 mr-2" />
                        收藏
                      </Button>
                      <Button variant="outline">
                        <Share2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* 章节列表 */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="bg-gradient-to-r from-blue-500 to-blue-600 px-4 py-3 rounded-t-lg">
                <h2 className="text-lg font-bold text-white">章节列表</h2>
              </div>
              <div className="p-4">
                <div className="mb-4 flex gap-2">
                  <Input placeholder="搜索章节..." className="flex-1" />
                  <Button variant="outline">搜索</Button>
                </div>
                <div className="space-y-1 max-h-[600px] overflow-y-auto">
                  {novel.chapters.map((chapter, index) => (
                    <Link
                      key={chapter.id}
                      href={`/novel/${novel.id}/chapter/${chapter.id}`}
                      onClick={() => setSelectedChapter(chapter)}
                      className="flex items-center justify-between p-3 hover:bg-yellow-50 rounded-lg transition-colors border border-transparent hover:border-yellow-200"
                    >
                      <div className="flex items-center space-x-3">
                        <span className="text-xs text-gray-400 w-12 text-right">
                          第{index + 1}章
                        </span>
                        <span className="text-sm text-gray-800 hover:text-yellow-600 transition-colors">
                          {chapter.title}
                        </span>
                      </div>
                      <div className="flex items-center space-x-4 text-xs text-gray-500">
                        <span>{chapter.wordCount}字</span>
                        <span>{chapter.updateTime.split(' ')[0]}</span>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* 右侧边栏 */}
          <div className="space-y-6">
            {/* 作者其他作品 */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="bg-gradient-to-r from-green-500 to-green-600 px-4 py-3 rounded-t-lg">
                <h3 className="font-bold text-white">作者其他作品</h3>
              </div>
              <div className="p-4 space-y-3">
                {mockNovels
                  .filter((n) => n.author === novel.author && n.id !== novel.id)
                  .slice(0, 5)
                  .map((n) => (
                    <Link
                      key={n.id}
                      href={`/novel/${n.id}`}
                      className="block p-2 hover:bg-gray-50 rounded transition-colors"
                    >
                      <p className="text-sm font-medium text-gray-800 hover:text-yellow-600 transition-colors truncate">
                        {n.title}
                      </p>
                      <p className="text-xs text-gray-500">{n.status}</p>
                    </Link>
                  ))}
              </div>
            </div>

            {/* 同类推荐 */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="bg-gradient-to-r from-purple-500 to-purple-600 px-4 py-3 rounded-t-lg">
                <h3 className="font-bold text-white">同类推荐</h3>
              </div>
              <div className="p-4 space-y-3">
                {mockNovels
                  .filter((n) => n.category === novel.category && n.id !== novel.id)
                  .slice(0, 5)
                  .map((n) => (
                    <Link
                      key={n.id}
                      href={`/novel/${n.id}`}
                      className="block p-2 hover:bg-gray-50 rounded transition-colors"
                    >
                      <p className="text-sm font-medium text-gray-800 hover:text-yellow-600 transition-colors truncate">
                        {n.title}
                      </p>
                      <p className="text-xs text-gray-500">{n.author}</p>
                    </Link>
                  ))}
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* 底部 */}
      <footer className="bg-gray-800 text-gray-400 py-8 mt-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm">黄金屋小说网 - 免费小说阅读网站</p>
        </div>
      </footer>
    </div>
  );
}
