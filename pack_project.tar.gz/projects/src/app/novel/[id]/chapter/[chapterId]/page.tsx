'use client';

import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { getNovelById } from '@/data/mock-novels';
import type { Novel, Chapter } from '@/types/novel';
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  List,
  Home,
  Settings,
  ChevronLeft,
  ChevronRight,
  Moon,
  Sun,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

export default function ReadChapterPage() {
  const params = useParams();
  const router = useRouter();
  const [novel, setNovel] = useState<Novel | null>(null);
  const [currentChapter, setCurrentChapter] = useState<Chapter | null>(null);
  const [fontSize, setFontSize] = useState(18);
  const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    const novelId = params.id as string;
    const chapterId = params.chapterId as string;
    const foundNovel = getNovelById(novelId);

    if (foundNovel) {
      setNovel(foundNovel);
      const chapter = foundNovel.chapters.find((ch) => ch.id === chapterId);
      setCurrentChapter(chapter || null);
    }
  }, [params.id, params.chapterId]);

  const handlePrevChapter = () => {
    if (!novel || !currentChapter) return;
    const currentIndex = novel.chapters.findIndex((ch) => ch.id === currentChapter.id);
    if (currentIndex > 0) {
      const prevChapter = novel.chapters[currentIndex - 1];
      router.push(`/novel/${novel.id}/chapter/${prevChapter.id}`);
    }
  };

  const handleNextChapter = () => {
    if (!novel || !currentChapter) return;
    const currentIndex = novel.chapters.findIndex((ch) => ch.id === currentChapter.id);
    if (currentIndex < novel.chapters.length - 1) {
      const nextChapter = novel.chapters[currentIndex + 1];
      router.push(`/novel/${novel.id}/chapter/${nextChapter.id}`);
    }
  };

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
  };

  if (!novel || !currentChapter) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-yellow-500 border-b-2 border-yellow-600">
          <div className="container mx-auto px-4 py-3">
            <Link href="/" className="text-white font-bold text-xl">
              黄金屋小说网
            </Link>
          </div>
        </header>
        <div className="container mx-auto px-4 py-12">
          <div className="text-center">
            <p className="text-gray-600">未找到该章节</p>
            <Link href="/">
              <Button className="mt-4">返回首页</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const currentChapterIndex = novel.chapters.findIndex((ch) => ch.id === currentChapter.id);
  const hasPrevChapter = currentChapterIndex > 0;
  const hasNextChapter = currentChapterIndex < novel.chapters.length - 1;

  return (
    <div
      className={`min-h-screen transition-colors ${
        isDarkMode ? 'bg-gray-900 text-gray-100' : 'bg-gray-50'
      }`}
    >
      {/* 顶部工具栏 */}
      <header
        className={`border-b shadow-sm sticky top-0 z-50 ${
          isDarkMode
            ? 'bg-gray-800 border-gray-700'
            : 'bg-white border-gray-200'
        }`}
      >
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link
                href={`/novel/${novel.id}`}
                className={`flex items-center space-x-2 text-sm ${
                  isDarkMode ? 'text-gray-300 hover:text-white' : 'text-gray-600 hover:text-yellow-600'
                }`}
              >
                <BookOpen className="h-4 w-4" />
                <span>{novel.title}</span>
              </Link>
            </div>

            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleDarkMode}
                className={isDarkMode ? 'text-gray-300 hover:text-white' : ''}
              >
                {isDarkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
              </Button>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className={isDarkMode ? 'text-gray-300 hover:text-white' : ''}>
                    <Settings className="h-4 w-4 mr-1" />
                    设置
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <div className="p-2 space-y-2">
                    <p className="text-sm font-medium">字号</p>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setFontSize(Math.max(14, fontSize - 2))}
                      >
                        <ChevronLeft className="h-3 w-3" />
                      </Button>
                      <span className="text-sm w-12 text-center">{fontSize}px</span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setFontSize(Math.min(24, fontSize + 2))}
                      >
                        <ChevronRight className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </DropdownMenuContent>
              </DropdownMenu>

              <Link href="/">
                <Button variant="ghost" size="sm" className={isDarkMode ? 'text-gray-300 hover:text-white' : ''}>
                  <Home className="h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* 章节导航 */}
      <div className="bg-yellow-500 text-white py-2">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center space-x-4">
              <Link
                href="/"
                className="hover:text-yellow-200 transition-colors"
              >
                首页
              </Link>
              <span>/</span>
              <Link
                href={`/novel/${novel.id}`}
                className="hover:text-yellow-200 transition-colors"
              >
                {novel.title}
              </Link>
            </div>
            <div className="flex items-center space-x-2">
              <span>
                第 {currentChapterIndex + 1} 章 / 共 {novel.chapters.length} 章
              </span>
              <Link
                href={`/novel/${novel.id}`}
                className="hover:text-yellow-200 transition-colors"
              >
                <List className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* 章节内容 */}
      <main className="container mx-auto px-4 py-6">
        <div className="max-w-4xl mx-auto">
          {/* 章节标题 */}
          <div
            className={`text-center mb-8 ${
              isDarkMode ? 'text-gray-100' : 'text-gray-800'
            }`}
          >
            <h1 className="text-2xl font-bold mb-2">{currentChapter.title}</h1>
            <p className="text-sm text-gray-500">
              更新时间：{currentChapter.updateTime} | 字数：{currentChapter.wordCount}
            </p>
          </div>

          {/* 章节正文 */}
          <div
            className={`leading-relaxed px-4 py-6 ${
              isDarkMode
                ? 'bg-gray-800 text-gray-200'
                : 'bg-white'
            } rounded-lg shadow-sm`}
            style={{ fontSize: `${fontSize}px`, lineHeight: '2' }}
          >
            {currentChapter.content.split('\n').map((paragraph, index) => (
              <p key={index} className="mb-4 text-justify indent-8">
                {paragraph}
              </p>
            ))}
          </div>

          {/* 章节导航按钮 */}
          <div className="flex items-center justify-between mt-8 space-x-4">
            <Button
              variant="outline"
              onClick={handlePrevChapter}
              disabled={!hasPrevChapter}
              className="flex-1"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              上一章
            </Button>
            <Link href={`/novel/${novel.id}`} className="flex-shrink-0">
              <Button variant="default" className="bg-yellow-500 hover:bg-yellow-600">
                <List className="h-4 w-4 mr-2" />
                目录
              </Button>
            </Link>
            <Button
              variant="outline"
              onClick={handleNextChapter}
              disabled={!hasNextChapter}
              className="flex-1"
            >
              下一章
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>

          {/* 快捷导航 */}
          <div
            className={`mt-6 p-4 rounded-lg ${
              isDarkMode ? 'bg-gray-800' : 'bg-white'
            } shadow-sm`}
          >
            <h3
              className={`font-semibold mb-3 ${isDarkMode ? 'text-gray-100' : 'text-gray-800'}`}
            >
              章节导航
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {novel.chapters.slice(Math.max(0, currentChapterIndex - 2), currentChapterIndex + 3).map((chapter) => (
                <Link
                  key={chapter.id}
                  href={`/novel/${novel.id}/chapter/${chapter.id}`}
                  className={`p-2 text-center text-sm rounded transition-colors ${
                    chapter.id === currentChapter.id
                      ? 'bg-yellow-500 text-white'
                      : isDarkMode
                      ? 'hover:bg-gray-700 text-gray-300'
                      : 'hover:bg-gray-100 text-gray-600'
                  }`}
                >
                  {chapter.title.length > 10
                    ? chapter.title.substring(0, 10) + '...'
                    : chapter.title}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </main>

      {/* 底部 */}
      <footer
        className={`mt-12 py-8 ${
          isDarkMode ? 'bg-gray-800 text-gray-400' : 'bg-gray-800 text-gray-400'
        }`}
      >
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm">黄金屋小说网 - 免费小说阅读网站</p>
        </div>
      </footer>
    </div>
  );
}
