'use client';

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { searchNovels, mockNovels, mockCategories } from '@/data/mock-novels';
import type { Novel } from '@/types/novel';
import {
  Search,
  BookOpen,
  Clock,
  User,
  ArrowLeft,
  Filter,
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

export default function SearchPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get('q') || '';
  const initialCategory = searchParams.get('category') || '';

  const [query, setQuery] = useState(initialQuery);
  const [category, setCategory] = useState(initialCategory);
  const [results, setResults] = useState<Novel[]>([]);
  const [hasSearched, setHasSearched] = useState(false);

  useEffect(() => {
    if (initialQuery) {
      handleSearch();
    }
  }, [initialQuery]);

  const handleSearch = () => {
    setHasSearched(true);
    let searchResults = mockNovels;

    if (query.trim()) {
      searchResults = searchNovels(query);
    }

    if (category) {
      searchResults = searchResults.filter((novel) => novel.category === category);
    }

    setResults(searchResults);

    // 更新URL
    const params = new URLSearchParams();
    if (query) params.set('q', query);
    if (category) params.set('category', category);
    router.push(`/search?${params.toString()}`, { scroll: false });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const handleCategoryChange = (newCategory: string) => {
    setCategory(newCategory === category ? '' : newCategory);
    if (newCategory !== category) {
      setTimeout(handleSearch, 0);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* 顶部导航 */}
      <header className="bg-yellow-500 border-b-2 border-yellow-600 shadow-md">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <BookOpen className="h-7 w-7 text-white" />
              <h1 className="text-xl font-bold text-white">黄金屋小说网</h1>
            </Link>
            <nav className="flex items-center space-x-4 text-white text-sm">
              <Link href="/" className="hover:text-yellow-200 transition-colors">
                首页
              </Link>
              <Link href="/categories" className="hover:text-yellow-200 transition-colors">
                分类
              </Link>
              <Link href="/rank" className="hover:text-yellow-200 transition-colors">
                排行
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* 搜索区域 */}
      <div className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 py-6">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center space-x-4">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <Input
                  type="text"
                  placeholder="搜索小说、作者..."
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className="pl-12 pr-4 py-3 text-lg border-2 focus:ring-2 focus:ring-yellow-300 focus:border-yellow-400"
                />
              </div>
              <Button
                onClick={handleSearch}
                className="bg-yellow-500 hover:bg-yellow-600 text-white px-8"
              >
                搜索
              </Button>
            </div>

            {/* 分类筛选 */}
            <div className="mt-4">
              <div className="flex items-center space-x-2 text-sm text-gray-600 mb-2">
                <Filter className="h-4 w-4" />
                <span className="font-medium">分类筛选：</span>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button
                  variant={!category ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => handleCategoryChange('')}
                  className={!category ? 'bg-yellow-500 hover:bg-yellow-600' : ''}
                >
                  全部
                </Button>
                {mockCategories.map((cat) => (
                  <Button
                    key={cat.id}
                    variant={category === cat.name ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => handleCategoryChange(cat.name)}
                    className={
                      category === cat.name ? 'bg-yellow-500 hover:bg-yellow-600' : ''
                    }
                  >
                    {cat.name}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 搜索结果 */}
      <main className="container mx-auto px-4 py-6">
        <div className="max-w-4xl mx-auto">
          {!hasSearched ? (
            // 未搜索状态
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12">
              <div className="text-center">
                <Search className="h-16 w-16 mx-auto text-gray-300 mb-4" />
                <h2 className="text-2xl font-bold text-gray-800 mb-2">
                  搜索小说
                </h2>
                <p className="text-gray-600 mb-6">
                  输入小说名称或作者名称，搜索您想看的小说
                </p>

                {/* 热门搜索 */}
                <div className="mt-8">
                  <h3 className="font-semibold text-gray-800 mb-4">热门搜索</h3>
                  <div className="flex flex-wrap gap-2 justify-center">
                    {mockNovels.slice(0, 8).map((novel) => (
                      <Link
                        key={novel.id}
                        href={`/novel/${novel.id}`}
                        className="px-3 py-1 bg-gray-100 hover:bg-yellow-100 text-gray-700 hover:text-yellow-700 rounded-full text-sm transition-colors"
                      >
                        {novel.title}
                      </Link>
                    ))}
                  </div>
                </div>

                {/* 热门分类 */}
                <div className="mt-8">
                  <h3 className="font-semibold text-gray-800 mb-4">热门分类</h3>
                  <div className="flex flex-wrap gap-2 justify-center">
                    {mockCategories.slice(0, 8).map((cat) => (
                      <Link
                        key={cat.id}
                        href={`/categories/${cat.id}`}
                        className="px-4 py-2 bg-gradient-to-r from-yellow-100 to-yellow-200 hover:from-yellow-200 hover:to-yellow-300 text-yellow-800 rounded-lg text-sm font-medium transition-colors"
                      >
                        {cat.name}
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ) : results.length === 0 ? (
            // 无结果
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12">
              <div className="text-center">
                <div className="text-6xl mb-4">📚</div>
                <h2 className="text-2xl font-bold text-gray-800 mb-2">
                  未找到相关结果
                </h2>
                <p className="text-gray-600 mb-6">
                  没有找到与"{query}"相关的小说，试试其他关键词吧
                </p>
                <div className="flex items-center justify-center space-x-4">
                  <Button variant="outline" onClick={() => {
                    setQuery('');
                    setCategory('');
                    setHasSearched(false);
                  }}>
                    清空搜索
                  </Button>
                  <Link href="/">
                    <Button className="bg-yellow-500 hover:bg-yellow-600">
                      返回首页
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          ) : (
            // 搜索结果列表
            <div className="space-y-4">
              <div className="flex items-center justify-between mb-4">
                <p className="text-gray-600">
                  找到 <span className="font-bold text-yellow-600">{results.length}</span> 本小说
                </p>
                {(query || category) && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setQuery('');
                      setCategory('');
                      setHasSearched(false);
                      router.push('/search');
                    }}
                  >
                    清空筛选
                  </Button>
                )}
              </div>

              <div className="space-y-4">
                {results.map((novel) => (
                  <Link
                    key={novel.id}
                    href={`/novel/${novel.id}`}
                    className="block bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md hover:border-yellow-300 transition-all group"
                  >
                    <div className="flex items-start space-x-4">
                      {/* 封面 */}
                      <div className="flex-shrink-0">
                        <div className="w-24 h-32 bg-gradient-to-br from-yellow-100 to-yellow-200 rounded flex items-center justify-center">
                          <BookOpen className="h-8 w-8 text-yellow-600" />
                        </div>
                      </div>

                      {/* 信息 */}
                      <div className="flex-1 min-w-0">
                        <h3 className="text-lg font-bold text-gray-800 mb-2 group-hover:text-yellow-600 transition-colors">
                          {novel.title}
                        </h3>
                        <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                          <span className="flex items-center">
                            <User className="h-4 w-4 mr-1" />
                            {novel.author}
                          </span>
                          <span className="flex items-center">
                            <BookOpen className="h-4 w-4 mr-1" />
                            {novel.category}
                          </span>
                          <span className="px-2 py-0.5 bg-yellow-100 text-yellow-700 rounded text-xs">
                            {novel.status}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 line-clamp-2 mb-2">
                          {novel.description}
                        </p>
                        <div className="flex items-center space-x-4 text-xs text-gray-500">
                          <span className="flex items-center">
                            <Clock className="h-3 w-3 mr-1" />
                            {novel.lastUpdateTime}
                          </span>
                          <span>共 {novel.chapters.length} 章</span>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>

      {/* 底部 */}
      <footer className="bg-gray-800 text-gray-400 py-8 mt-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm">黄金屋小说网 - 免费小说阅读网站</p>
        </div>
      </footer>
    </div>
  );
}
