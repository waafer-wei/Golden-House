export interface Novel {
  id: string;
  title: string;
  author: string;
  cover: string;
  description: string;
  category: string;
  status: string;
  lastUpdateTime: string;
  chapters: Chapter[];
}

export interface Chapter {
  id: string;
  title: string;
  content: string;
  wordCount: number;
  updateTime: string;
}

export interface Category {
  id: string;
  name: string;
  count: number;
}
