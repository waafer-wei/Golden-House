# 黄金屋小说网 - 部署指南

本文档介绍如何将黄金屋小说网部署到生产环境。

## 方案一：Vercel 部署（推荐）

### 优势
- ✅ 零配置，一键部署
- ✅ 免费HTTPS证书
- ✅ 全球CDN加速
- ✅ 自动持续部署
- ✅ 免费额度充足（每月100GB带宽）

### 部署步骤

#### 1. 准备代码
```bash
# 确保代码已提交到 Git 仓库
git init
git add .
git commit -m "Initial commit"

# 推送到 GitHub/GitLab/Bitbucket
git remote add origin <你的仓库地址>
git push -u origin main
```

#### 2. 注册 Vercel
访问 https://vercel.com 注册账号（推荐使用 GitHub 账号登录）

#### 3. 导入项目
1. 登录后点击 "Add New..." → "Project"
2. 选择你的 GitHub 仓库
3. Vercel 会自动检测 Next.js 项目
4. 点击 "Deploy" 开始部署

#### 4. 配置域名
1. 部署完成后，进入项目设置
2. 点击 "Domains"
3. 输入你的域名（如：`huangjinwu.com`）
4. Vercel 会提供 DNS 配置信息

#### 5. 配置 DNS
在你的域名注册商（阿里云、腾讯云、GoDaddy等）添加以下记录：

```
类型: CNAME
名称: @
值: cname.vercel-dns.com

类型: CNAME
名称: www
值: cname.vercel-dns.com
```

#### 6. 等待生效
DNS 生效通常需要 10 分钟到 24 小时，Vercel 会自动配置 SSL 证书。

---

## 方案二：自建服务器部署

### 环境要求
- Linux 服务器（Ubuntu 20.04+ 推荐）
- Node.js 18+
- Nginx
- 域名

### 部署步骤

#### 1. 安装依赖
```bash
# 更新系统
sudo apt update && sudo apt upgrade -y

# 安装 Node.js 18
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# 验证安装
node -v
npm -v

# 安装 pnpm
npm install -g pnpm

# 安装 Nginx
sudo apt install -y nginx
```

#### 2. 上传代码
```bash
# 在本地打包项目
pnpm install
pnpm build

# 将项目文件上传到服务器
scp -r . user@your-server:/var/www/huangjinwu
```

#### 3. 配置 Nginx
创建 Nginx 配置文件：

```nginx
# /etc/nginx/sites-available/huangjinwu
server {
    listen 80;
    server_name huangjinwu.com www.huangjinwu.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

启用配置：
```bash
sudo ln -s /etc/nginx/sites-available/huangjinwu /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

#### 4. 使用 PM2 运行应用
```bash
# 安装 PM2
sudo npm install -g pm2

# 在项目目录下启动
cd /var/www/huangjinwu
pm2 start npm --name "huangjinwu" -- start

# 设置开机自启
pm2 startup
pm2 save
```

#### 5. 配置 SSL 证书（使用 Let's Encrypt）
```bash
# 安装 Certbot
sudo apt install -y certbot python3-certbot-nginx

# 获取证书（自动配置 Nginx）
sudo certbot --nginx -d huangjinwu.com -d www.huangjinwu.com

# 自动续期
sudo certbot renew --dry-run
```

---

## 方案三：Docker 部署

### 创建 Dockerfile
```dockerfile
FROM node:18-alpine

WORKDIR /app

# 安装 pnpm
RUN npm install -g pnpm

# 复制依赖文件
COPY package.json pnpm-lock.yaml ./

# 安装依赖
RUN pnpm install --frozen-lockfile

# 复制项目文件
COPY . .

# 构建应用
RUN pnpm build

# 暴露端口
EXPOSE 3000

# 启动应用
CMD ["pnpm", "start"]
```

### 创建 docker-compose.yml
```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
    restart: unless-stopped
```

### 构建和运行
```bash
# 构建镜像
docker build -t huangjinwu .

# 使用 docker-compose 运行
docker-compose up -d

# 查看日志
docker-compose logs -f
```

### 配置 Nginx 反向代理
参考方案二的 Nginx 配置，将 `proxy_pass` 改为：
```nginx
proxy_pass http://localhost:3000;
```

---

## 方案四：阿里云 / 腾讯云部署

### 阿里云部署

#### 1. 使用云服务器 ECS
- 购买 ECS 实例（选择 Ubuntu 系统）
- 参考方案二的部署步骤

#### 2. 使用轻量应用服务器
- 选择 Node.js 镜像
- 上传代码，使用 PM2 运行

#### 3. 使用云函数 / Serverless
- 需要适配 Serverless 环境
- 使用阿里云 Serverless Devs 工具部署

### 腾讯云部署

#### 1. 使用云服务器 CVM
- 参考 ECS 部署步骤

#### 2. 使用云开发
- 创建 Web 应用
- 上传 Next.js 构建产物
- 配置域名和 SSL

---

## 域名配置通用步骤

### 1. 购买域名
- 阿里云：https://wanwang.aliyun.com
- 腾讯云：https://dnspod.cloud.tencent.com
- 其他：GoDaddy、Namecheap 等

### 2. 配置 DNS 记录

#### A 记录（指向服务器IP）
```
类型: A
名称: @
值: 你的服务器IP地址
TTL: 600
```

#### CNAME 记录（指向服务）
```
类型: CNAME
名称: www
值: 主域名或服务地址
TTL: 600
```

#### 记录类型说明
- **A 记录**：将域名指向 IPv4 地址
- **CNAME 记录**：将域名指向另一个域名
- **AAAA 记录**：将域名指向 IPv6 地址

### 3. 验证域名解析
```bash
# 检查 A 记录
nslookup huangjinwu.com

# 检查 CNAME 记录
nslookup www.huangjinwu.com
```

### 4. 配置 SSL/TLS
- **Let's Encrypt**：免费证书，90天有效期，可自动续期
- **云服务商证书**：阿里云、腾讯云提供免费证书
- **付费证书**：DigiCert、GlobalSign 等

---

## 常见问题

### Q1: 域名解析后访问 404
**A**: 检查 Nginx 配置是否正确，确保 `server_name` 与域名一致

### Q2: HTTPS 证书不生效
**A**: 
- 确保域名已正确解析
- 检查防火墙是否开放 80 和 443 端口
- 重新申请证书

### Q3: PM2 重启后应用停止
**A**: 使用 `pm2 save` 保存进程列表，确保开机自启

### Q4: 静态资源加载失败
**A**: 
- 检查 Next.js 配置中的 `output: 'standalone'`
- 确保 Nginx 配置正确

### Q5: 构建失败
**A**: 
- 清除缓存：`rm -rf .next node_modules`
- 重新安装依赖：`pnpm install`
- 检查 Node.js 版本是否匹配

---

## 性能优化建议

### 1. 启用 Gzip 压缩
```nginx
gzip on;
gzip_vary on;
gzip_min_length 1024;
gzip_types text/plain text/css text/xml text/javascript application/x-javascript application/xml+rss application/json;
```

### 2. 配置缓存
```nginx
# 静态资源缓存
location /_next/static/ {
    expires 1y;
    add_header Cache-Control "public, immutable";
}
```

### 3. 使用 CDN
- 静态资源上传到对象存储
- 配置 CDN 加速

### 4. 数据库优化
- 使用连接池
- 配置 Redis 缓存

---

## 监控和维护

### 1. 日志监控
```bash
# PM2 日志
pm2 logs huangjinwu

# Nginx 日志
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log
```

### 2. 性能监控
- 使用 PM2 监控面板：`pm2 monit`
- 配置告警通知

### 3. 备份
- 定期备份数据库
- 备份配置文件

---

## 成本估算

### Vercel 免费额度
- 带宽：100GB/月
- 执行时间：10000小时/月
- 适合个人项目和小型网站

### 自建服务器成本
- VPS（2核4G）：约 ¥50-100/月
- 域名：约 ¥50-年
- SSL证书：免费（Let's Encrypt）

### 推荐选择
- **新手/个人项目**：Vercel（免费，省心）
- **企业/高流量**：自建服务器（可控性强）
- **国内访问**：阿里云/腾讯云（网络更好）

---

## 技术支持

- Vercel 文档：https://vercel.com/docs
- Next.js 部署：https://nextjs.org/docs/deployment
- Nginx 文档：https://nginx.org/en/docs/
