# 🚀 Vercel 部署操作指南

## 当前状态

✅ Git 仓库已初始化
✅ 代码已提交（3 个提交）
❌ 远程仓库未配置

## 下一步操作

### 第一步：在 GitHub 创建仓库

1. 访问 https://github.com/new
2. 创建新仓库，填写：
   - 仓库名称：`huangjinwu-novel`（或你喜欢的名字）
   - 可见性：Public 或 Private
   - 不要初始化 README、.gitignore
3. 点击 "Create repository"

### 第二步：添加远程仓库并推送

创建仓库后，GitHub 会显示推送命令，执行以下命令：

```bash
# 添加远程仓库（替换 YOUR_USERNAME 为你的 GitHub 用户名）
git remote add origin https://github.com/YOUR_USERNAME/huangjinwu-novel.git

# 推送代码到 GitHub
git push -u origin main
```

### 第三步：在 Vercel 导入项目

1. 访问 https://vercel.com 并登录（建议使用 GitHub 登录）
2. 点击 "Add New..." → "Project"
3. 在 "Import Git Repository" 中找到 `huangjinwu-novel`
4. 点击 "Import"
5. 确认配置（自动检测 Next.js 项目）
6. 点击 "Deploy" 开始部署

### 第四步：等待部署完成

- 部署时间：1-3 分钟
- 部署完成后会获得临时域名：`https://huangjinwu-novel.vercel.app`

### 第五步：绑定你的域名（可选）

1. 部署完成后，进入项目 "Settings" → "Domains"
2. 添加你的域名（如 `huangjinwu.com`）
3. 在域名管理后台添加 DNS 记录：

| 类型 | 名称 | 值 |
|------|------|-----|
| CNAME | @ | cname.vercel-dns.com |
| CNAME | www | cname.vercel-dns.com |

4. 等待 DNS 生效（10 分钟 - 24 小时）

## 📝 示例操作

假设你的 GitHub 用户名是 `zhangsan`，操作如下：

```bash
# 1. 在 GitHub 创建仓库：https://github.com/zhangsan/huangjinwu-novel

# 2. 添加远程仓库
git remote add origin https://github.com/zhangsan/huangjinwu-novel.git

# 3. 推送代码
git push -u origin main

# 4. 访问 Vercel 导入项目
```

## ❓ 如果推送失败

### 错误：remote already exists
```bash
# 移除现有远程仓库
git remote remove origin

# 重新添加
git remote add origin https://github.com/YOUR_USERNAME/huangjinwu-novel.git
```

### 错误：Authentication failed
- 确保你有 GitHub 账号的访问权限
- 如果使用个人访问令牌，需要配置 Git 凭据

### 错误：repository not found
- 确认仓库名称拼写正确
- 确认仓库已在 GitHub 上创建

## 📚 详细文档

完整部署指南：[VERCEL_DEPLOY.md](./VERCEL_DEPLOY.md)

## ✅ 部署检查清单

- [ ] GitHub 仓库已创建
- [ ] 远程仓库已配置
- [ ] 代码已推送到 GitHub
- [ ] Vercel 项目已导入
- [ ] 部署成功（获得 .vercel.app 域名）
- [ ] （可选）自定义域名已配置
- [ ] （可选）DNS 记录已添加

## 💡 提示

1. 首次推送可能需要输入 GitHub 凭据
2. 建议使用 SSH 方式（更安全）：`git@github.com:YOUR_USERNAME/huangjinwu-novel.git`
3. 推送后所有更改都会自动部署到 Vercel

---

准备好后，按照上述步骤操作即可！如有问题请参考 VERCEL_DEPLOY.md 文档。
