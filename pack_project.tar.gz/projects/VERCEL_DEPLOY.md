# 🚀 黄金屋小说网 - Vercel 部署指南

本指南将帮助你通过 Vercel 将黄金屋小说网部署到你的域名。

## 📋 部署前准备

### 1. 准备工作清单
- [ ] 拥有 GitHub 账号
- [ ] 拥有 Vercel 账号（可用 GitHub 登录）
- [ ] 已购买域名（可选，Vercel 提供免费子域名）
- [ ] 本地代码已完成并测试

### 2. 项目文件检查
确保项目根目录包含以下文件：
- ✅ `package.json` - 项目依赖配置
- ✅ `vercel.json` - Vercel 部署配置
- ✅ `.vercelignore` - 忽略文件配置
- ✅ `.gitignore` - Git 忽略文件

---

## 📦 第一步：推送到 GitHub

### 1.1 创建 GitHub 仓库
1. 访问 https://github.com/new
2. 仓库名称：`huangjinwu-novel`（或你喜欢的名字）
3. 选择 Public 或 Private（根据需求）
4. 不要初始化 README、.gitignore 或 license
5. 点击 "Create repository"

### 1.2 初始化本地 Git 仓库
```bash
# 在项目根目录执行
cd /workspace/projects

# 初始化 Git
git init

# 添加所有文件
git add .

# 提交代码
git commit -m "feat: 初始化黄金屋小说网项目"

# 添加远程仓库（替换为你的仓库地址）
git remote add origin https://github.com/你的用户名/huangjinwu-novel.git

# 推送到 GitHub
git branch -M main
git push -u origin main
```

### 1.3 验证推送成功
访问你的 GitHub 仓库，确认所有文件都已上传。

---

## 🌐 第二步：导入到 Vercel

### 2.1 登录 Vercel
1. 访问 https://vercel.com
2. 点击 "Sign Up" 或 "Login"
3. 使用 GitHub 账号登录（推荐）
4. 授权 Vercel 访问你的 GitHub 仓库

### 2.2 导入项目
1. 登录后，点击 "Add New..." → "Project"
2. 在 "Import Git Repository" 列表中找到 `huangjinwu-novel`
3. 如果没有显示，点击 "Adjust" → "Import from Git" → 选择仓库
4. 点击 "Import"

### 2.3 配置项目设置
Vercel 会自动检测到 Next.js 项目，配置如下：

```
Project Name: huangjinwu-novel
Framework Preset: Next.js
Root Directory: ./
Build Command: pnpm build
Output Directory: .next
Install Command: pnpm install
```

**重要设置：**
- ✅ 确认 `Build Command` 为 `pnpm build`
- ✅ 确认 `Install Command` 为 `pnpm install`
- ✅ 确保 `Node.js Version` 为 18 或更高（在 "Environment Variables" 中设置）

### 2.4 添加环境变量（可选）
如果有环境变量，在 "Environment Variables" 中添加：
- `NODE_ENV` = `production`

### 2.5 开始部署
1. 点击 "Deploy" 按钮
2. 等待 1-3 分钟构建完成
3. 部署成功后会获得一个临时域名：
   ```
   https://huangjinwu-novel.vercel.app
   ```

---

## 🌍 第三步：绑定你的域名

### 3.1 进入域名设置
1. 部署完成后，进入项目页面
2. 点击顶部的 "Settings" 标签
3. 在左侧菜单点击 "Domains"

### 3.2 添加域名
1. 在 "Domains" 页面，点击 "Add" 按钮
2. 输入你的域名（例如：`huangjinwu.com`）
3. 点击 "Add"

### 3.3 配置 DNS 记录

Vercel 会提供两种配置方式，推荐使用方式一：

#### 方式一：CNAME 记录（推荐）

如果你使用顶级域名（如 `huangjinwu.com`），在你的域名管理后台添加：

| 类型 | 名称 | 值 | TTL |
|------|------|-----|-----|
| CNAME | @ | cname.vercel-dns.com | 600 |
| CNAME | www | cname.vercel-dns.com | 600 |

如果你的域名支持 ALIAS 记录（推荐）：

| 类型 | 名称 | 值 | TTL |
|------|------|-----|-----|
| ALIAS | @ | cname.vercel-dns.com | 600 |
| CNAME | www | cname.vercel-dns.com | 600 |

#### 方式二：A 记录（不推荐，仅备用）

| 类型 | 名称 | 值 | TTL |
|------|------|-----|-----|
| A | @ | 76.76.21.21 | 600 |
| A | @ | 76.76.19.61 | 600 |

### 3.4 常见域名配置示例

#### 阿里云配置
```
主机记录: @
记录类型: CNAME
记录值: cname.vercel-dns.com

主机记录: www
记录类型: CNAME
记录值: cname.vercel-dns.com
```

#### 腾讯云配置
```
主机记录: @
记录类型: CNAME
记录值: cname.vercel-dns.com

主机记录: www
记录类型: CNAME
记录值: cname.vercel-dns.com
```

#### GoDaddy 配制
```
Type: CNAME
Name: @
Value: cname.vercel-dns.com

Type: CNAME
Name: www
Value: cname.vercel-dns.com
```

### 3.5 等待 DNS 生效
- DNS 生效时间：10 分钟 - 24 小时
- Vercel 会自动检测 DNS 配置
- 配置正确后，Vercel 会自动颁发 SSL 证书

### 3.6 验证部署
访问你的域名：
```
https://huangjinwu.com
https://www.huangjinwu.com
```

---

## 🔧 第四步：配置选项（可选但推荐）

### 4.1 启用 HTTPS
Vercel 默认为所有域名启用 HTTPS，无需额外配置。

### 4.2 设置重定向
将 `www` 重定向到主域名（或反之）：

1. 进入 "Domains" 设置
2. 找到你的域名
3. 点击 "Edit Configuration"
4. 选择重定向规则

### 4.3 配置环境变量
如果有需要，进入 "Settings" → "Environment Variables" 添加。

### 4.4 设置自定义 404 页面
创建 `src/app/not-found.tsx`（Next.js 默认已有）。

---

## 🔄 第五步：自动持续部署

Vercel 已配置自动持续部署，每次你推送代码到 GitHub，Vercel 会自动：

1. 检测到新的提交
2. 自动拉取代码
3. 运行 `pnpm install`
4. 运行 `pnpm build`
5. 部署到生产环境

### 预览部署
每次推送到 `main` 分支之外的分支（如 `dev`、`feature`），Vercel 会创建预览部署。

---

## 📊 监控和管理

### 查看部署日志
1. 进入项目页面
2. 点击 "Deployments" 标签
3. 点击具体部署，查看构建日志

### 查看访问统计
1. 进入 "Analytics" 标签
2. 查看访问量、性能等数据

### 回滚到之前的版本
1. 进入 "Deployments"
2. 找到想要回滚的部署
3. 点击 "..." → "Promote to Production"

---

## ❌ 常见问题排查

### Q1: 部署失败 - Build Error
**原因**：依赖安装失败或构建错误

**解决方法**：
```bash
# 本地测试构建
pnpm install
pnpm build

# 检查 Node.js 版本
node -v  # 应该 >= 18
```

### Q2: DNS 配置后访问 404
**原因**：DNS 未生效或配置错误

**解决方法**：
```bash
# 检查 DNS 解析
nslookup huangjinwu.com
# 或
dig huangjinwu.com

# 等待 10-30 分钟后重试
```

### Q3: SSL 证书不生效
**原因**：DNS 未正确配置或证书正在签发

**解决方法**：
- 确保 DNS 已生效
- 等待 24 小时让 Vercel 自动签发证书
- 检查 Vercel "Domains" 页面的证书状态

### Q4: 静态资源加载失败
**原因**：缓存问题或路径错误

**解决方法**：
1. 清除浏览器缓存
2. 重新部署项目
3. 检查 `vercel.json` 配置

### Q5: 页面加载慢
**原因**：首次冷启动

**解决方法**：
- Vercel 会自动优化
- 访问几次后会加速（CDN 缓存）

---

## 💰 Vercel 免费额度

| 资源 | 免费额度 |
|------|----------|
| 带宽 | 100GB/月 |
| 执行时间 | 10000小时/月 |
| 构建时间 | 6000分钟/月 |
| 域名 | 无限 |
| SSL证书 | 免费 |
| CDN | 全球免费 |

> 免费额度足够个人和小型项目使用！

---

## 📈 性能优化建议

### 1. 启用图片优化
Next.js 默认已启用，确保使用 `next/image` 组件。

### 2. 启用缓存
已配置在 `vercel.json` 中，静态资源缓存 1 年。

### 3. 减少包体积
```bash
# 查看包体积分析
pnpm add -D @next/bundle-analyzer
```

### 4. 启用 Gzip 压缩
Vercel 默认已启用。

---

## 🛡️ 安全建议

1. ✅ **启用 HTTPS**：Vercel 默认启用
2. ✅ **配置安全头部**：已配置在 `vercel.json`
3. ✅ **环境变量保护**：敏感信息不要提交到代码
4. ✅ **定期更新依赖**：`pnpm update`

---

## 📞 获取帮助

### 官方资源
- Vercel 文档：https://vercel.com/docs
- Next.js 部署：https://nextjs.org/docs/deployment
- Vercel 社区：https://vercel.com/community

### 常用命令
```bash
# 本地构建测试
pnpm build

# 预览生产构建
pnpm start

# 查看 Vercel CLI 命令
vercel --help
```

---

## 🎉 部署完成！

恭喜！你的黄金屋小说网已成功部署到 Vercel！

✅ 访问你的网站：https://你的域名.com
✅ 管理你的项目：https://vercel.com/dashboard

---

## 📝 快速参考

### 更新网站流程
```bash
# 1. 修改代码
vim src/app/page.tsx

# 2. 提交并推送
git add .
git commit -m "fix: 修复xxx问题"
git push

# 3. Vercel 自动部署，等待 1-2 分钟
# 4. 访问网站查看更新
```

### 查看部署状态
- Vercel Dashboard → 你的项目 → Deployments
- 查看最新部署的状态和日志

### 删除项目
- Vercel Dashboard → 你的项目 → Settings → General
- 滚动到底部，点击 "Delete Project"

---

祝你使用愉快！🚀
